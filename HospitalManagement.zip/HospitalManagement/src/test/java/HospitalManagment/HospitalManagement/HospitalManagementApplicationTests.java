package HospitalManagment.HospitalManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hospital.dao.FeedbackRepository;
import com.hospital.model.Feedback;
import com.hospital.dao.AppointmentRepository;
import com.hospital.model.Appointment;
import com.hospital.dao.PatientSignupRepository;
import com.hospital.model.PatientSignup;
import com.hospital.dao.DoctorRepository;
import com.hospital.model.Doctor;


@SpringBootTest
class HospitalManagementApplicationTests {
	@Autowired
	FeedbackRepository feedbackRepository;

	@Test
	
	public void addFeedback() {
		Feedback feedback = new Feedback();
		feedback.setFeedback_id(3);
		feedback.setP_id(2);
		feedback.setP_comments("san");
		
		assertNotNull(feedbackRepository.findById(18).get());
	}
	@Test
	public void AllFeedback() {
		List<Feedback> list = feedbackRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void Feedback() {
		Feedback feedback = feedbackRepository.findById(18).get();
		assertEquals(18, feedback.getFeedback_id());


}
	@Autowired
	AppointmentRepository appointmentRepository;
	@Test
	
	public void addAppointment() {
		Appointment appointment = new Appointment();
		appointment.setap_id(5);
		appointment.setDisease("corona");
		appointment.setAddress("Pune");
                appointment.setAp_status("booked");
                appointment.setap_time("12:30");
            	//Date ap_date = new ap_date();
                appointment.setAp_date("");
                appointment.setd_id(11); 
                appointment.setp_id(5); 

		
		assertNotNull(appointmentRepository.findById(5).get());
	}
	@Test
	public void AllAppointment() {
		List<Appointment> list = appointmentRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void Appointment() {
		Appointment appointment = appointmentRepository.findById(5).get();
		assertEquals(5, appointment.getp_id());


}
	@Autowired
	PatientSignupRepository patientsignupRepository;
	@Test
	
	public void addPatientSignup() {
		PatientSignup patientsignup = new PatientSignup();
		 patientsignup.setP_id(5);
	    // patientsignup.setDob("");
		 patientsignup.setP_contact_no(12);
         patientsignup.setP_gender("female");
         patientsignup.setP_name("manii");
         patientsignup.setP_password("mom@12");
         patientsignup.setUsername("");


		
		assertNotNull(patientsignupRepository.findById(8).get());
	}
	@Test
	public void AllPatientSignup() {
		List<PatientSignup> list = patientsignupRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void PatientSignup() {
		PatientSignup patientsignup = patientsignupRepository.findById(8).get();
		assertEquals(8,patientsignup.getP_id());


}
		
	@Autowired
	DoctorRepository doctorRepository;
	@Test
	
	public void addDoctor() {
		Doctor doctor = new Doctor();
		 doctor.setD_id(11);
	     doctor.setAddress("");
		 doctor.setContact_No(65783);
         doctor.setGender("");
         doctor.setSpecialization("");
         doctor.setD_password("");
         doctor.setMail_id("");
         doctor.setD_name(""); 
         doctor.setUsername("");
		
		assertNotNull(doctorRepository.findById(20).get());
	}
	@Test
	public void AllDoctor() {
		List<Doctor> list = doctorRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void Doctor() {
		Doctor doctor = doctorRepository.findById(20).get();
		assertEquals(20,doctor.getD_id());


}
		
}