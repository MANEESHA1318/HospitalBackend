package com.hospital.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hospital.model.PatientSignup;

@Repository
public interface PatientSignupRepository extends JpaRepository<PatientSignup ,Integer>{
	@Query("SELECT p FROM PatientSignup p WHERE p.p_name =?1 and p.p_password=?2")
	public PatientSignup validateUser(String name,String password);
}
