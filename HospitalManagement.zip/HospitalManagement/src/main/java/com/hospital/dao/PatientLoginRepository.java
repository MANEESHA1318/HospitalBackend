package com.hospital.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hospital.model.PatientLogin;


public interface PatientLoginRepository extends JpaRepository<PatientLogin, Integer> {
	@Query("SELECT pl FROM PatientLogin pl WHERE pl.id =?1 and pl.pPassword=?2")
	public PatientLogin validatePatientLogin(int id,String pPassword);
}
