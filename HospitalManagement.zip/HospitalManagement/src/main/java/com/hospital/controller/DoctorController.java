package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.exception.ResourceNotFoundException;
import com.hospital.model.Doctor;
import com.hospital.service.DoctorService;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class DoctorController {
	@Autowired
	DoctorService dService;
	//http://localhost:8090/api/v1/doctorloginUser
		@GetMapping("/doctorloginUser")
		public ResponseEntity<Object> validateUser(@RequestBody Doctor user) 		
		{
			Doctor d = dService.validateUser(user);
			if (d==null)
			
			return new ResponseEntity<>("Invalid credentials",HttpStatus.NOT_FOUND);
			else
				return new ResponseEntity<>("Successful login", HttpStatus.OK);
		}

//http://localhost:8080/api/v1/doctors
	@GetMapping("/doctors")
	public List<Doctor> getDoctors() {
		List<Doctor> dList = dService.fetchDoctors();

		
		return dList;

	}

	// http://localhost:8080/api/v1/doctors/45 
	@GetMapping("/doctors/{d_id}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable("d_id") int d_id)
			throws ResourceNotFoundException {
		Doctor d = dService.getDoctor(d_id);
		return ResponseEntity.ok().body(d);
	}

	// http://localhost:8080/api/v1/doctors
	@PostMapping("/doctors")
	public Doctor addPatient(@RequestBody Doctor d) {

		Doctor doctor = dService.saveDoctor(d);

		
		return doctor;
	}

	// http://localhost:8080/api/v1/doctors/2
	@PutMapping("/doctors/{d_id}")
	public ResponseEntity<Doctor> updateDoctor(@PathVariable("d_id") int d_id,
			@RequestBody Doctor DoctorDetails) throws ResourceNotFoundException {
		Doctor d = dService.getDoctor(d_id);

		
		d.setD_name(DoctorDetails.getD_name());
		
		d.setGender(DoctorDetails.getGender());
		d.setD_password(DoctorDetails.getD_password());
		d.setMail_id(DoctorDetails.getMail_id());
		d.setContact_No(DoctorDetails.getContact_No());
		d.setAddress(DoctorDetails.getAddress());
		d.setUsername(DoctorDetails.getUsername());
		
		d.setSpecialization(DoctorDetails.getSpecialization());
		final Doctor updatedDoctor = dService.saveDoctor(d);
		return ResponseEntity.ok(updatedDoctor);
	}

//http://localhost:8080/api/v1/doctors/1
	@DeleteMapping(value = "/doctors/{d_id}")
	public ResponseEntity<Object> deletePatient(@PathVariable("d_id") int d_id) {

		dService.deleteDoctor(d_id);
		return new ResponseEntity<>("Doctor deleted successsfully", HttpStatus.OK);
	}
	
}

