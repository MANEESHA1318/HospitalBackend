package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.exception.ResourceNotFoundException;
import com.hospital.model.PatientLogin;
import com.hospital.model.PatientSignup;
import com.hospital.service.PatientLoginService;
import com.hospital.service.PatientSignupService;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class PatientController {

	@Autowired
	PatientSignupService pService;

//http://localhost:8080/api/v1/patients
	@GetMapping("/patients")
	public List<PatientSignup> getPatients() {
		List<PatientSignup> pList = pService.fetchPatients();

		return pList;

	}

	// http://localhost:8080/api/v1/patient/1
	@GetMapping("/patient/{p_id}")
	public ResponseEntity<PatientSignup> getPatientById(@PathVariable("p_id") int p_id)
			throws ResourceNotFoundException {
		PatientSignup p = pService.getPatient(p_id);
		return ResponseEntity.ok().body(p);
	}

	// http://localhost:8080/api/v1/patients
	@PostMapping("/patients")
	public PatientSignup addPatient(@RequestBody PatientSignup p) {

		PatientSignup patient = pService.savePatient(p);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return patient;
	}

	// http://localhost:8080/api/v1/patients/2
	@PutMapping("/patients/{p_id}")
	public ResponseEntity<PatientSignup> updatePatient(@PathVariable("p_id") int p_id,
			@RequestBody PatientSignup PatientDetails) throws ResourceNotFoundException {
		PatientSignup p = pService.getPatient(p_id);

		
	
		p.setP_contact_no(PatientDetails.getP_contact_no());
		p.setP_password(PatientDetails.getP_password());
		p.setP_name(PatientDetails.getP_name());
		p.setDob(PatientDetails.getDob());
		p.setP_gender(PatientDetails.getP_gender());
		p.setUsername(PatientDetails.getUsername());
		
		final PatientSignup updatedPatient = pService.savePatient(p);
		return ResponseEntity.ok(updatedPatient);
	}

//http://localhost:8080/api/v1/patients/1
	@DeleteMapping(value = "/patients/{p_id}")
	public ResponseEntity<Object> deletePatient(@PathVariable("p_id") int p_id) {

		pService.deletePatient(p_id);
		return new ResponseEntity<>("Patient deleted successsfully", HttpStatus.OK);
	}
	
	@PostMapping("/loginPatient")
	public PatientSignup validateUser(@RequestBody PatientSignup user) 		
	{
		System.out.println("in controller="+user.getP_name());
		PatientSignup u = pService.validateUser(user);
		return u;
	}
	
	public class PatientLoginController {
		@Autowired
		PatientLoginService patientloginService;
		
		@GetMapping("/login")
		public ResponseEntity<Object> validatePatientLogin(@RequestBody PatientLogin patientlogin) 		
		{
			PatientLogin pl = patientloginService.validatePatientLogin(patientlogin);
			if (pl==null)
			
			return new ResponseEntity<>("Invalid credentials",HttpStatus.NOT_FOUND);
			else
				return new ResponseEntity<>("Successful login", HttpStatus.OK);
		}
}
}