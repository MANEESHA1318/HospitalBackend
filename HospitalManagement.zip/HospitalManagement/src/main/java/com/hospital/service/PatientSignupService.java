package com.hospital.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.PatientSignupRepository;
import com.hospital.model.PatientSignup;


@Service
public class PatientSignupService {

	@Autowired
	PatientSignupRepository patientsignupRepository;
	
	@Transactional
	public List<PatientSignup> fetchPatients() {
		List<PatientSignup> patientList=patientsignupRepository.findAll();
		return patientList;
		
	}
	@Transactional
	public PatientSignup savePatient(PatientSignup patientsignup) {
		
		return patientsignupRepository.save(patientsignup);
		
	}
	@Transactional
	public void update(PatientSignup p) {
		patientsignupRepository.save(p);	
	
	}
	
	@Transactional
	public void deletePatient(int p_id) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
		patientsignupRepository.deleteById(p_id);
	
	}
	@Transactional 
	  public PatientSignup getPatient(int p_id) { 
	  Optional<PatientSignup> optional= patientsignupRepository.findById(p_id);
	  PatientSignup p=optional.get();
	  return p;
	  }
	
	public PatientSignup validateUser(PatientSignup user) {
		PatientSignup u=patientsignupRepository.validateUser(user.getP_name(),user.getP_password());
		
		return u;
	}
}
