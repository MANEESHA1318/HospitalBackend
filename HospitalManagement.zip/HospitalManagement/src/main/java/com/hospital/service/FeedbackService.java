package com.hospital.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.FeedbackRepository;
import com.hospital.model.Feedback;



@Service
public class FeedbackService {

	@Autowired
	FeedbackRepository servicesRepository;
	
	@Transactional
	public List<Feedback> fetchFeedback() {
		List<Feedback> feedbackList=servicesRepository.findAll();
		return feedbackList;
		
	}
	@Transactional
	public Feedback saveFeedback(Feedback feedback) {
		
		return servicesRepository.save(feedback);
		
	}
	@Transactional
	public void updateFeedback(Feedback feedback) {
		servicesRepository.save(feedback);	
	
	}
	
	@Transactional
	public void deleteFeedback(int feedback_id) {
		System.out.println("service method called");
		servicesRepository.deleteById(feedback_id);
	
	}
	@Transactional 
	  public Feedback getFeedback(int feedback_id) { 
	  Optional<Feedback> optional= servicesRepository.findById(feedback_id);
	  Feedback feedback=optional.get();
	  return feedback;
	  }
	
}
