package com.hospital.model;
import javax.persistence.Column;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="patientdetails")
public class PatientLogin {
	@Id
	@Column(name="patient_id")
	private int id;
	@Column(name="password")
	private String pPassword;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPPassword() {
		return pPassword;
	}

	public void setPPassword(String pPassword) {
		this.pPassword = pPassword;
	}

}
