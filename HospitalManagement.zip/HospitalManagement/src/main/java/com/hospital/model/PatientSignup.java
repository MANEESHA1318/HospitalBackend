package com.hospital.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="patient_signup")
public class PatientSignup {

	@Id
	@GeneratedValue
	@Column(name="p_id")
	private int p_id;
	
	
	@Column(name="dob")
	@Temporal(TemporalType. DATE) 
	private Date dob;
	
	@Column(name="p_gender")
	private String p_gender;
	
	@Column(name="p_contact_no")
	private int p_contact_no;
	
	@Column(name="p_name")
	private String p_name;
	@Column(name="username")
	private String username;
	@Column(name="p_password")
	private String p_password;

	public PatientSignup(int p_id,  Date dob, String p_gender, int p_contact_no, String p_name, String p_password,String username) {
		super();
		this.p_id = p_id;
		
		this.dob = dob;
		this.username=username;
		this.p_gender = p_gender;
		this.p_contact_no = p_contact_no;
		this.p_name = p_name;
		this.p_password = p_password;
	}
	
	public PatientSignup()
	{
		
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}



	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getP_gender() {
		return p_gender;
	}

	public void setP_gender(String p_gender) {
		this.p_gender = p_gender;
	}

	public int getP_contact_no() {
		return p_contact_no;
	}

	public void setP_contact_no(int p_contact_no) {
		this.p_contact_no = p_contact_no;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_password() {
		return p_password;
	}

	public void setP_password(String p_password) {
		this.p_password = p_password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	
}
