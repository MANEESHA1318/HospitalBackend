package com.hospital.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="appointment")
public class Appointment {

	@Id
	@GeneratedValue
	@Column(name="AP_ID ")
	private int ap_id ;
	
	@Column(name="P_ID ")
	private int p_id;

	@Column(name="ADDRESS  ")
	private String address;
	@Column(name=" D_ID")
	private int d_id;
	@Column(name="AP_DATE ")
	
	private String ap_date  ;

	@Column(name="AP_TIME ")
	private String ap_time ;

	@Column(name="AP_STATUS ")
	private String ap_status ;
	


	@Column(name="Disease ")
	private String Disease ;
	
	
	
	

	public Appointment(int p_id,String address,int d_id,int ap_id, String ap_date,String ap_time,String ap_status ,String Disease) {
		super();
		this.p_id = p_id;
		
		this.address = address;
		
		this.d_id = d_id;
		this.ap_id = ap_id;
		this.ap_date=ap_date ;
		this.ap_time = ap_time;
		
		this.ap_status = ap_status;
		this.Disease=Disease;
		

	}
	
	public Appointment()
	{
		
	}

	public int getp_id() {
		return p_id;
	}

	public void setp_id(int p_id) {
		this.p_id = p_id;
	}


	public int getd_id() {
		return d_id;
	}

	public void setd_id(int d_id) {
		this.d_id = d_id;
	}
	public String getAp_date() {
		return ap_date;
	}

	public void setAp_date(String ap_date) {
		this.ap_date = ap_date;
	}

	public int getap_id() {
		return ap_id;
	}

	public void setap_id(int ap_id) {
		this.ap_id = ap_id;
	}
	
	




	public String getap_time() {
		return ap_time;
	}

	public void setap_time(String ap_time) {
		this.ap_time = ap_time;
	}	
	public String getAddress() {
		return address;
	}

	public void setAddress(String adress) {
		this.address = adress;
	}

	public String getAp_status() {
		return ap_status;
	}

	public void setAp_status(String ap_status) {
		this.ap_status = ap_status;
	}

	public String getDisease() {
		return Disease;
	}

	public void setDisease(String disease) {
		Disease = disease;
	}

}
